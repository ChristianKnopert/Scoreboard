public class Match {
    static int scoreTeamOne = 0;
    static int scoreTeamTwo = 0;
    static String totalScore;



    public static int resetScore(){
        Match.scoreTeamOne = 0;
        Match.scoreTeamTwo = 0;
        return 0;
    }

    public static String updateScore(){
            totalScore = String.valueOf(scoreTeamOne +" - "+ scoreTeamTwo);
            return totalScore;
            }



    public static void increaseScoreTeamOne(){
        Match.scoreTeamOne++;
    }

    public static void increaseScoreTeamTwo(){
        Match.scoreTeamTwo++;
    }

    public static void decreaseScoreTeamOne(){
        Match.scoreTeamOne--;
        }

    public static void decreaseScoreTeamTwo(){
        Match.scoreTeamTwo--;
        }



    }




