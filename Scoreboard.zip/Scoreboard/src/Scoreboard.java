public class Scoreboard {

    public static void main(String[] args){
        Match.resetScore();
        System.out.println(Match.updateScore());

        Match.increaseScoreTeamOne();
        System.out.println(Match.updateScore());

        Match.increaseScoreTeamOne();
        System.out.println(Match.updateScore());

        Match.increaseScoreTeamTwo();
        System.out.println(Match.updateScore());

        Match.decreaseScoreTeamOne();
        System.out.println(Match.updateScore());

        Match.increaseScoreTeamTwo();
        System.out.println(Match.updateScore());

        Match.decreaseScoreTeamTwo();
        System.out.println(Match.updateScore());

        Match.decreaseScoreTeamTwo();
        System.out.println(Match.updateScore());

        Match.decreaseScoreTeamTwo();
        System.out.println(Match.updateScore());

        Match.resetScore();
        System.out.println(Match.updateScore());

    }


}
